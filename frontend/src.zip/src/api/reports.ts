import api from './client'

export const reportsApi = {
  mostBorrowed: async (startDate: string, endDate: string, limit = 10) => {
    const response = await api.get(
      `/reports/most-borrowed?startDate=${startDate}&endDate=${endDate}&limit=${limit}`
    )
    return response.data.data
  },

  overdue: async () => {
    const response = await api.get('/reports/overdue')
    return response.data.data
  },

  activeMembers: async (startDate: string, endDate: string, limit = 10) => {
    const response = await api.get(
      `/reports/active-members?startDate=${startDate}&endDate=${endDate}&limit=${limit}`
    )
    return response.data.data
  },

  fineCollection: async (startDate: string, endDate: string) => {
    const response = await api.get(
      `/reports/fine-collection?startDate=${startDate}&endDate=${endDate}`
    )
    return response.data.data
  },

  inventory: async () => {
    const response = await api.get('/reports/inventory')
    return response.data.data
  },

  downloadExcel: async (reportType: string, params?: Record<string, string>) => {
    const queryString = params ? '?' + new URLSearchParams(params).toString() : ''
    const response = await api.get(`/reports/${reportType}/export/excel${queryString}`, {
      responseType: 'blob',
    })
    return response.data
  },

  downloadPdf: async (reportType: string, params?: Record<string, string>) => {
    const queryString = params ? '?' + new URLSearchParams(params).toString() : ''
    const response = await api.get(`/reports/${reportType}/export/pdf${queryString}`, {
      responseType: 'blob',
    })
    return response.data
  },
}