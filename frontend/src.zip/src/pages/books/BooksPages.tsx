import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Search, BookOpen } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { booksApi } from '@/api/books'

export function BooksPage() {
  const [search, setSearch] = useState('')

  const { data, isLoading } = useQuery({
    queryKey: ['books', search],
    queryFn: () =>
      search ? booksApi.search(search) : booksApi.getAll(0, 20),
  })

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Books Catalog</h1>
          <p className="text-muted-foreground">Browse our collection</p>
        </div>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search by title, author, ISBN..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {isLoading ? (
        <div>Loading...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {data?.content?.map((book) => (
            <Card key={book.id} className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="p-4">
                <div className="aspect-[3/4] bg-gradient-to-br from-blue-100 to-indigo-100 rounded-lg mb-3 flex items-center justify-center">
                  <BookOpen className="w-16 h-16 text-blue-400" />
                </div>

                <h3 className="font-semibold text-sm line-clamp-2 mb-1">{book.title}</h3>
                <p className="text-xs text-muted-foreground mb-2">
                  {book.authors?.join(', ') || 'Unknown Author'}
                </p>

                <div className="flex flex-wrap gap-1 mb-2">
                  {book.categories?.slice(0, 2).map((cat) => (
                    <Badge key={cat} variant="secondary" className="text-xs">
                      {cat}
                    </Badge>
                  ))}
                </div>

                <div className="flex items-center justify-between mt-3 pt-3 border-t">
                  <div className="text-xs">
                    <p className="font-semibold">
                      {book.availableCopies}/{book.totalCopies}
                    </p>
                    <p className="text-muted-foreground">Available</p>
                  </div>
                  <Badge variant={book.available ? 'success' : 'destructive'}>
                    {book.available ? 'Available' : 'Borrowed'}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}