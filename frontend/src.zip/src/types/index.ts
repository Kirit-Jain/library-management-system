// ============================================
// API Response wrapper
// ============================================
export interface ApiResponse<T> {
  success: boolean
  message?: string
  data: T
  error?: string
  validationErrors?: Record<string, string>
  timestamp: string
}

export interface PageResponse<T> {
  content: T[]
  totalElements: number
  totalPages: number
  number: number
  size: number
  first: boolean
  last: boolean
}

// ============================================
// User & Auth
// ============================================
export interface User {
  id: number
  username: string
  email: string
  fullName: string
  role: string
}

export interface JwtResponse {
  accessToken: string
  refreshToken: string
  tokenType: string
  expiresIn: number
  user: User
}

export interface LoginRequest {
  email: string
  password: string
}

export interface RegisterRequest {
  username: string
  email: string
  password: string
  firstName: string
  lastName: string
  phone?: string
  address?: string
}

// ============================================
// Books
// ============================================
export interface Book {
  id: number
  isbn: string
  title: string
  description?: string
  publisherName?: string
  publicationYear?: number
  edition?: string
  language: string
  pageCount?: number
  coverImageUrl?: string
  totalCopies: number
  availableCopies: number
  available: boolean
  authors: string[]
  categories: string[]
  createdAt: string
}

export interface BookLocation {
  bookId: number
  isbn: string
  title: string
  totalCopies: number
  availableCopies: number
  copies: BookCopyLocation[]
}

export interface BookCopyLocation {
  copyId: number
  barcode: string
  branchName?: string
  branchAddress?: string
  floorName?: string
  floorNumber?: number
  sectionName?: string
  sectionCode?: string
  shelfCode?: string
  status: string
  condition: string
  expectedReturnDate?: string
  locationDescription?: string
}

// ============================================
// Members
// ============================================
export interface Member {
  id: number
  userId: number
  membershipNumber: string
  fullName: string
  email: string
  phone?: string
  membershipType: 'STANDARD' | 'PREMIUM' | 'STUDENT' | 'SENIOR'
  maxBooksAllowed: number
  maxBorrowDays: number
  membershipStart: string
  membershipExpiry: string
  isActive: boolean
  membershipExpired: boolean
  totalFinesPending: number
  currentBorrowedCount: number
}

// ============================================
// Borrowings
// ============================================
export interface Borrowing {
  id: number
  memberId: number
  memberName: string
  membershipNumber: string
  bookCopyId: number
  barcode: string
  bookTitle: string
  bookIsbn: string
  borrowDate: string
  dueDate: string
  returnDate?: string
  renewedCount: number
  status: 'ACTIVE' | 'RETURNED' | 'OVERDUE' | 'LOST'
  isOverdue: boolean
  overdueDays: number
  notes?: string
  createdAt: string
}

// ============================================
// Fines
// ============================================
export interface Fine {
  id: number
  memberId: number
  memberName: string
  membershipNumber: string
  borrowingId: number
  bookTitle: string
  barcode: string
  amount: number
  paidAmount: number
  remainingAmount: number
  fineType: 'OVERDUE' | 'LOST_BOOK' | 'DAMAGED_BOOK'
  status: 'UNPAID' | 'PAID' | 'WAIVED'
  fineDate: string
  dueDate?: string
  paidDate?: string
  notes?: string
}

// ============================================
// Dashboard
// ============================================
export interface DashboardStats {
  totalBooks: number
  totalBookCopies: number
  availableCopies: number
  borrowedCopies: number
  totalMembers: number
  activeMembers: number
  activeBorrowings: number
  overdueBorrowings: number
  borrowingsToday: number
  returnsToday: number
  totalUnpaidFines: number
  totalCollectedFines: number
  pendingReservations: number
}

// ============================================
// Notifications
// ============================================
export interface Notification {
  id: number
  title: string
  message: string
  type: string
  isRead: boolean
  createdAt: string
}